package anahuerta.tfg.electronicsstorev2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectronicsStoreV2Application {

	public static void main(String[] args) {
		SpringApplication.run(ElectronicsStoreV2Application.class, args);
	}

}
