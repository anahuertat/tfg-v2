package anahuerta.tfg.electronicsstorev2.domain;
//tengo que añadir mas categorias
public enum Category {
	CABLES, SENSORS, RESISTORS
}
